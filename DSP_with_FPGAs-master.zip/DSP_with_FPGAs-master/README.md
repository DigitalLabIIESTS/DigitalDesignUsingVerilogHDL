Source files for the book "Digital Signal Processing with Field Programmable Gate Arrays" (4. edition) by Uwe Meyer-Baese.

The book CD files can be found here: http://extras.springer.com/2014/978-3-642-45308-3
